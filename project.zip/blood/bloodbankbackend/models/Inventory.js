const mongoose = require('mongoose');

const inventorySchema = new mongoose.Schema({
  bloodType: String,
  units: Number
});

module.exports = mongoose.model('Inventory', inventorySchema);