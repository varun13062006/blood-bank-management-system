const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  name: String,
  email: { type: String, unique: true },
  password: String,
  role: { type: String, enum: ['donor', 'recipient', 'admin'], default: 'donor' },
  bloodType: String,
  location: String
});

module.exports = mongoose.model('User', userSchema);