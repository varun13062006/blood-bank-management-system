const mongoose = require('mongoose');

const requestSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  bloodType: String,
  units: Number,
  status: { type: String, enum: ['pending', 'approved', 'fulfilled', 'declined'], default: 'pending' },
  dateRequested: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Request', requestSchema);