const mongoose = require('mongoose');

const donationSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  date: Date,
  status: { type: String, enum: ['scheduled', 'completed'], default: 'scheduled' }
});

module.exports = mongoose.model('Donation', donationSchema);