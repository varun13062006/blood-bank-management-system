const express = require('express');
const router = express.Router();
const Request = require('../models/Request');
const Inventory = require('../models/Inventory');
const auth = require('../middleware/authMiddleware');

router.use(auth);

router.get('/requests', async (req, res) => {
  const all = await Request.find().populate('userId');
  res.json(all);
});

router.post('/update-status/:id', async (req, res) => {
  const request = await Request.findByIdAndUpdate(req.params.id, { status: req.body.status }, { new: true });
  res.json(request);
});

router.get('/inventory', async (req, res) => {
  const stock = await Inventory.find();
  res.json(stock);
});

module.exports = router;