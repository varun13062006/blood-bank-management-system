const express = require('express');
const router = express.Router();
const Donation = require('../models/Donation');
const auth = require('../middleware/authMiddleware');

router.post('/schedule', auth, async (req, res) => {
  const donation = await Donation.create({ userId: req.user._id, date: req.body.date });
  res.json(donation);
});

router.get('/my-donations', auth, async (req, res) => {
  const list = await Donation.find({ userId: req.user._id });
  res.json(list);
});

module.exports = router;