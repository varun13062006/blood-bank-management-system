const express = require('express');
const router = express.Router();
const Request = require('../models/Request');
const Donation = require('../models/Donation');
const auth = require('../middleware/authMiddleware');

router.use(auth);

router.get('/summary', async (req, res) => {
  const totalDonations = await Donation.countDocuments();
  const totalRequests = await Request.countDocuments();
  res.json({ totalDonations, totalRequests });
});

module.exports = router;