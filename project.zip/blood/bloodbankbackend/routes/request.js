const express = require('express');
const router = express.Router();
const Request = require('../models/Request');
const auth = require('../middleware/authMiddleware');

router.post('/', auth, async (req, res) => {
  const request = await Request.create({ ...req.body, userId: req.user._id });
  res.json(request);
});

router.get('/my-requests', auth, async (req, res) => {
  const list = await Request.find({ userId: req.user._id });
  res.json(list);
});

module.exports = router;