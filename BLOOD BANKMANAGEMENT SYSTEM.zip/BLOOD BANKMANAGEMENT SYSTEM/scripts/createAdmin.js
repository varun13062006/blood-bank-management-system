const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
require('dotenv').config();

// Import User model
const User = require('../models/User');

// MongoDB Connection
mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/bloodbank', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
.then(() => console.log('Connected to MongoDB'))
.catch(err => console.error('MongoDB connection error:', err));

async function createAdminUser() {
  try {
    // Check if admin already exists
    const existingAdmin = await User.findOne({ email: 'admin@bloodbank.com' });
    
    if (existingAdmin) {
      console.log('Admin user already exists');
      process.exit(0);
    }

    // Create admin user
    const adminUser = new User({
      fullName: 'System Administrator',
      email: 'admin@bloodbank.com',
      password: 'admin123', // This will be hashed automatically
      bloodGroup: 'O+',
      city: 'System',
      role: 'admin',
      age: 30,
      gender: 'Other'
    });

    await adminUser.save();
    
    console.log('Admin user created successfully!');
    console.log('Email: admin@bloodbank.com');
    console.log('Password: admin123');
    console.log('Please change the password after first login.');
    
  } catch (error) {
    console.error('Error creating admin user:', error);
  } finally {
    mongoose.connection.close();
    process.exit(0);
  }
}

// Run the script
createAdminUser();
