const mongoose = require('mongoose');

const donationSchema = new mongoose.Schema({
  donor: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  bloodGroup: {
    type: String,
    required: true,
    enum: ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-']
  },
  quantity: {
    type: Number,
    required: true,
    default: 1, // 1 unit = 450ml
    min: 1,
    max: 2
  },
  donationDate: {
    type: Date,
    required: true,
    default: Date.now
  },
  expiryDate: {
    type: Date,
    required: true
  },
  status: {
    type: String,
    enum: ['pending', 'approved', 'completed', 'rejected'],
    default: 'pending'
  },
  healthCheck: {
    hemoglobin: {
      type: Number,
      required: true,
      min: 12.5, // Minimum for females
      max: 20
    },
    bloodPressure: {
      systolic: {
        type: Number,
        required: true,
        min: 90,
        max: 180
      },
      diastolic: {
        type: Number,
        required: true,
        min: 60,
        max: 110
      }
    },
    pulse: {
      type: Number,
      required: true,
      min: 50,
      max: 100
    },
    temperature: {
      type: Number,
      required: true,
      min: 36.1,
      max: 37.2
    }
  },
  notes: {
    type: String,
    trim: true
  },
  location: {
    type: String,
    required: true
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

// Calculate expiry date (42 days from donation)
donationSchema.pre('save', function(next) {
  if (this.isNew) {
    this.expiryDate = new Date(this.donationDate.getTime() + (42 * 24 * 60 * 60 * 1000));
  }
  next();
});

// Index for efficient queries
donationSchema.index({ bloodGroup: 1, status: 1, expiryDate: 1 });
donationSchema.index({ donor: 1, donationDate: 1 });

module.exports = mongoose.model('Donation', donationSchema);
