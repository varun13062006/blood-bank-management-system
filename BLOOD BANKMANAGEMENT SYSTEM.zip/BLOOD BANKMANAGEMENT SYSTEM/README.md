# Blood Bank Management System

A comprehensive blood bank management system built with Node.js, Express.js, and MongoDB. This system provides user authentication, blood donation management, blood request handling, and administrative controls.

## Features

### User Features
- User registration and authentication
- Blood donation submission with health check validation
- Blood request submission for patients
- Profile management
- Donation history tracking
- Eligibility checking for donations
- Blood stock availability checking

### Admin Features
- User management
- Donation approval and status management
- Blood request management
- Dashboard with statistics
- Blood stock monitoring

### System Features
- JWT-based authentication
- Input validation and sanitization
- MongoDB database with Mongoose ODM
- RESTful API endpoints
- Responsive web interface

## Prerequisites

- Node.js (v14 or higher)
- MongoDB (v4.4 or higher)
- npm or yarn package manager

## Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd blood-bank-management-system
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Set up environment variables**
   Create a `.env` file in the root directory with the following variables:
   ```env
   MONGODB_URI=mongodb://localhost:27017/bloodbank
   JWT_SECRET=your-super-secret-jwt-key-change-this-in-production
   PORT=3000
   NODE_ENV=development
   ```

4. **Start MongoDB**
   Make sure MongoDB is running on your system. If using MongoDB locally:
   ```bash
   mongod
   ```

5. **Run the application**
   ```bash
   # Development mode with auto-restart
   npm run dev
   
   # Production mode
   npm start
   ```

6. **Access the application**
   Open your browser and navigate to `http://localhost:3000`

## API Endpoints

### Authentication
- `POST /api/auth/register` - User registration
- `POST /api/auth/login` - User login
- `POST /api/auth/admin-login` - Admin login
- `GET /api/auth/verify` - Verify JWT token
- `POST /api/auth/logout` - Logout

### Users
- `GET /api/users/profile` - Get user profile
- `PUT /api/users/profile` - Update user profile
- `GET /api/users/donations` - Get user's donations
- `GET /api/users/requests` - Get user's blood requests
- `GET /api/users/eligibility` - Check donation eligibility
- `GET /api/users/blood-stock` - Get available blood stock
- `PUT /api/users/change-password` - Change password

### Donations
- `POST /api/donations` - Submit blood donation
- `GET /api/donations/:id` - Get donation by ID
- `PUT /api/donations/:id` - Update donation
- `DELETE /api/donations/:id` - Cancel donation
- `GET /api/donations/stock/available` - Get available blood stock
- `GET /api/donations/stats/user` - Get user donation statistics

### Blood Requests
- `POST /api/requests` - Submit blood request
- `GET /api/requests/:id` - Get request by ID
- `PUT /api/requests/:id` - Update request
- `DELETE /api/requests/:id` - Cancel request
- `GET /api/requests/search/donors` - Search for donors
- `GET /api/requests/stats/user` - Get user request statistics
- `GET /api/requests/emergency/urgent` - Get urgent requests

### Admin
- `GET /api/admin/users` - Get all users
- `GET /api/admin/users/:id` - Get user by ID
- `PUT /api/admin/users/:id/role` - Update user role
- `DELETE /api/admin/users/:id` - Delete user
- `GET /api/admin/donations` - Get all donations
- `PUT /api/admin/donations/:id/status` - Update donation status
- `GET /api/admin/requests` - Get all blood requests
- `PUT /api/admin/requests/:id/status` - Update request status
- `GET /api/admin/dashboard` - Get admin dashboard statistics

## Database Models

### User
- Personal information (name, email, password)
- Blood group and location
- Health information (age, gender)
- Donation eligibility tracking
- Role-based access control

### Donation
- Donor information
- Blood group and quantity
- Health check data
- Status tracking (pending, approved, completed, rejected)
- Expiry date calculation

### BloodRequest
- Patient and hospital information
- Blood requirements
- Urgency levels
- Status tracking
- Assignment to donations

## Usage

### For Users
1. Register an account with your details
2. Login to access your dashboard
3. Submit blood donation requests
4. Submit blood requests for patients
5. Track your donation history and eligibility

### For Admins
1. Login with admin credentials
2. Access the admin dashboard
3. Manage user accounts and roles
4. Approve or reject blood donations
5. Monitor blood stock levels
6. Handle blood request approvals

## Security Features

- Password hashing with bcrypt
- JWT token authentication
- Input validation and sanitization
- Role-based access control
- Secure API endpoints

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## License

This project is licensed under the MIT License.

## Support

For support and questions, please open an issue in the repository or contact the development team.

## Future Enhancements

- Email notifications
- SMS alerts for urgent requests
- Mobile application
- Advanced analytics and reporting
- Integration with hospital systems
- Blood compatibility checking
- Donor-recipient matching algorithms
