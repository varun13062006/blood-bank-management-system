const express = require('express');
const { body, validationResult } = require('express-validator');
const BloodRequest = require('../models/BloodRequest');
const Donation = require('../models/Donation');
const User = require('../models/User');
const router = express.Router();

// Middleware to verify JWT token
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ message: 'Access token required' });
  }

  const jwt = require('jsonwebtoken');
  const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key';
  
  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({ message: 'Invalid or expired token' });
    }
    req.user = user;
    next();
  });
};

// Submit blood request
router.post('/', authenticateToken, [
  body('patientName').trim().isLength({ min: 2 }).withMessage('Patient name must be at least 2 characters'),
  body('bloodGroup').isIn(['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-']).withMessage('Valid blood group is required'),
  body('quantity').isInt({ min: 1, max: 10 }).withMessage('Quantity must be between 1 and 10 units'),
  body('urgency').isIn(['normal', 'urgent', 'emergency']).withMessage('Valid urgency level is required'),
  body('requiredBy').isISO8601().withMessage('Valid date is required'),
  body('hospital.name').trim().isLength({ min: 2 }).withMessage('Hospital name is required'),
  body('hospital.address').trim().isLength({ min: 5 }).withMessage('Hospital address is required'),
  body('hospital.contact').optional().trim(),
  body('reason').trim().isLength({ min: 10 }).withMessage('Reason must be at least 10 characters'),
  body('notes').optional().trim()
], async (req, res) => {
  try {
    // Check validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const {
      patientName,
      bloodGroup,
      quantity,
      urgency,
      requiredBy,
      hospital,
      reason,
      notes
    } = req.body;

    // Check if required date is in the future
    const requiredDate = new Date(requiredBy);
    if (requiredDate <= new Date()) {
      return res.status(400).json({ 
        message: 'Required date must be in the future' 
      });
    }

    // Create new blood request
    const bloodRequest = new BloodRequest({
      requester: req.user.userId,
      patientName,
      bloodGroup,
      quantity,
      urgency,
      requiredBy: requiredDate,
      hospital,
      reason,
      notes
    });

    await bloodRequest.save();

    res.status(201).json({
      message: 'Blood request submitted successfully',
      request: {
        id: bloodRequest._id,
        patientName: bloodRequest.patientName,
        bloodGroup: bloodRequest.bloodGroup,
        quantity: bloodRequest.quantity,
        urgency: bloodRequest.urgency,
        status: bloodRequest.status,
        requiredBy: bloodRequest.requiredBy
      }
    });

  } catch (error) {
    console.error('Submit request error:', error);
    res.status(500).json({ message: 'Server error during request submission' });
  }
});

// Get blood request by ID
router.get('/:id', authenticateToken, async (req, res) => {
  try {
    const request = await BloodRequest.findById(req.params.id)
      .populate('requester', 'fullName email bloodGroup city');

    if (!request) {
      return res.status(404).json({ message: 'Blood request not found' });
    }

    // Check if user is authorized to view this request
    if (request.requester._id.toString() !== req.user.userId && req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Access denied' });
    }

    res.json(request);

  } catch (error) {
    console.error('Get request error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Update blood request (only by requester before approval)
router.put('/:id', authenticateToken, [
  body('patientName').optional().trim().isLength({ min: 2 }).withMessage('Patient name must be at least 2 characters'),
  body('requiredBy').optional().isISO8601().withMessage('Valid date is required'),
  body('hospital.name').optional().trim().isLength({ min: 2 }).withMessage('Hospital name must be at least 2 characters'),
  body('hospital.address').optional().trim().isLength({ min: 5 }).withMessage('Hospital address must be at least 5 characters'),
  body('hospital.contact').optional().trim(),
  body('reason').optional().trim().isLength({ min: 10 }).withMessage('Reason must be at least 10 characters'),
  body('notes').optional().trim()
], async (req, res) => {
  try {
    // Check validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const request = await BloodRequest.findById(req.params.id);
    if (!request) {
      return res.status(404).json({ message: 'Blood request not found' });
    }

    // Check if user is authorized to update this request
    if (request.requester.toString() !== req.user.userId) {
      return res.status(403).json({ message: 'Access denied' });
    }

    // Only allow updates if request is still pending
    if (request.status !== 'pending') {
      return res.status(400).json({ 
        message: 'Cannot update request that has already been processed' 
      });
    }

    const updates = req.body;
    delete updates.bloodGroup; // Prevent blood group changes
    delete updates.quantity; // Prevent quantity changes
    delete updates.urgency; // Prevent urgency changes
    delete updates.requester; // Prevent requester changes

    // Validate required date if being updated
    if (updates.requiredBy) {
      const requiredDate = new Date(updates.requiredBy);
      if (requiredDate <= new Date()) {
        return res.status(400).json({ 
          message: 'Required date must be in the future' 
        });
      }
    }

    const updatedRequest = await BloodRequest.findByIdAndUpdate(
      req.params.id,
      { $set: updates },
      { new: true, runValidators: true }
    ).populate('requester', 'fullName email bloodGroup');

    res.json({
      message: 'Blood request updated successfully',
      request: updatedRequest
    });

  } catch (error) {
    console.error('Update request error:', error);
    res.status(500).json({ message: 'Server error during request update' });
  }
});

// Cancel blood request (only by requester if pending)
router.delete('/:id', authenticateToken, async (req, res) => {
  try {
    const request = await BloodRequest.findById(req.params.id);
    if (!request) {
      return res.status(404).json({ message: 'Blood request not found' });
    }

    // Check if user is authorized to cancel this request
    if (request.requester.toString() !== req.user.userId) {
      return res.status(403).json({ message: 'Access denied' });
    }

    // Only allow cancellation if request is still pending
    if (request.status !== 'pending') {
      return res.status(400).json({ 
        message: 'Cannot cancel request that has already been processed' 
      });
    }

    await BloodRequest.findByIdAndDelete(req.params.id);

    res.json({ message: 'Blood request cancelled successfully' });

  } catch (error) {
    console.error('Cancel request error:', error);
    res.status(500).json({ message: 'Server error during request cancellation' });
  }
});

// Search for available blood donors
router.get('/search/donors', authenticateToken, async (req, res) => {
  try {
    const { bloodGroup, city, radius = 50 } = req.query;

    if (!bloodGroup) {
      return res.status(400).json({ message: 'Blood group is required' });
    }

    // Find users with matching blood group
    let userQuery = { bloodGroup };
    if (city) {
      userQuery.city = { $regex: city, $options: 'i' };
    }

    const potentialDonors = await User.find(userQuery)
      .select('fullName email bloodGroup city phone lastDonationDate')
      .sort({ lastDonationDate: 1 }); // Prioritize those who haven't donated recently

    // Filter eligible donors
    const eligibleDonors = potentialDonors.filter(user => {
      if (!user.lastDonationDate) return true;
      
      const daysSinceLastDonation = Math.floor(
        (Date.now() - user.lastDonationDate.getTime()) / (1000 * 60 * 60 * 24)
      );
      
      return daysSinceLastDonation >= 56; // 56 days minimum
    });

    // Get current blood stock for the requested blood group
    const availableStock = await Donation.aggregate([
      {
        $match: {
          bloodGroup,
          status: 'completed',
          expiryDate: { $gt: new Date() }
        }
      },
      {
        $group: {
          _id: null,
          totalUnits: { $sum: '$quantity' }
        }
      }
    ]);

    const stockUnits = availableStock[0]?.totalUnits || 0;

    res.json({
      bloodGroup,
      requestedCity: city,
      availableStock: stockUnits,
      eligibleDonors: eligibleDonors.slice(0, 20), // Limit to top 20
      totalEligibleDonors: eligibleDonors.length,
      note: 'Contact donors directly to arrange donation'
    });

  } catch (error) {
    console.error('Search donors error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Get blood request statistics for a user
router.get('/stats/user', authenticateToken, async (req, res) => {
  try {
    const totalRequests = await BloodRequest.countDocuments({ requester: req.user.userId });
    const pendingRequests = await BloodRequest.countDocuments({ 
      requester: req.user.userId, 
      status: 'pending' 
    });
    const approvedRequests = await BloodRequest.countDocuments({ 
      requester: req.user.userId, 
      status: 'approved' 
    });
    const fulfilledRequests = await BloodRequest.countDocuments({ 
      requester: req.user.userId, 
      status: 'fulfilled' 
    });

    const urgencyStats = await BloodRequest.aggregate([
      { $match: { requester: req.user.userId } },
      {
        $group: {
          _id: '$urgency',
          count: { $sum: 1 }
        }
      },
      { $sort: { _id: 1 } }
    ]);

    const bloodGroupStats = await BloodRequest.aggregate([
      { $match: { requester: req.user.userId } },
      {
        $group: {
          _id: '$bloodGroup',
          count: { $sum: 1 },
          totalUnits: { $sum: '$quantity' }
        }
      },
      { $sort: { _id: 1 } }
    ]);

    res.json({
      totalRequests,
      pendingRequests,
      approvedRequests,
      fulfilledRequests,
      urgencyStats,
      bloodGroupStats,
      lastUpdated: new Date()
    });

  } catch (error) {
    console.error('Get request stats error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Get emergency blood requests (public endpoint for urgent cases)
router.get('/emergency/urgent', async (req, res) => {
  try {
    const { bloodGroup, city } = req.query;
    
    let query = {
      urgency: { $in: ['urgent', 'emergency'] },
      status: 'pending'
    };
    
    if (bloodGroup) {
      query.bloodGroup = bloodGroup;
    }
    
    if (city) {
      query['hospital.address'] = { $regex: city, $options: 'i' };
    }

    const urgentRequests = await BloodRequest.find(query)
      .populate('requester', 'fullName bloodGroup city')
      .sort({ urgency: -1, createdAt: 1 })
      .limit(10);

    res.json({
      urgentRequests,
      note: 'These are urgent blood requests that need immediate attention',
      lastUpdated: new Date()
    });

  } catch (error) {
    console.error('Get emergency requests error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;
