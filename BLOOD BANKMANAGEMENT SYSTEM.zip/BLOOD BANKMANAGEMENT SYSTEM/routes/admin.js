const express = require('express');
const { body, validationResult } = require('express-validator');
const User = require('../models/User');
const Donation = require('../models/Donation');
const BloodRequest = require('../models/BloodRequest');
const router = express.Router();

// Middleware to verify JWT token and admin role
const authenticateAdmin = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ message: 'Access token required' });
  }

  const jwt = require('jsonwebtoken');
  const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key';
  
  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({ message: 'Invalid or expired token' });
    }
    if (user.role !== 'admin') {
      return res.status(403).json({ message: 'Admin access required' });
    }
    req.user = user;
    next();
  });
};

// Get all users
router.get('/users', authenticateAdmin, async (req, res) => {
  try {
    const { page = 1, limit = 10, search = '', bloodGroup = '', city = '' } = req.query;
    
    let query = {};
    
    if (search) {
      query.$or = [
        { fullName: { $regex: search, $options: 'i' } },
        { email: { $regex: search, $options: 'i' } }
      ];
    }
    
    if (bloodGroup) {
      query.bloodGroup = bloodGroup;
    }
    
    if (city) {
      query.city = { $regex: city, $options: 'i' };
    }

    const users = await User.find(query)
      .select('-password')
      .sort({ createdAt: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit);

    const total = await User.countDocuments(query);

    res.json({
      users,
      totalPages: Math.ceil(total / limit),
      currentPage: page,
      total
    });

  } catch (error) {
    console.error('Get users error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Get user by ID
router.get('/users/:id', authenticateAdmin, async (req, res) => {
  try {
    const user = await User.findById(req.params.id).select('-password');
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    res.json(user);
  } catch (error) {
    console.error('Get user error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Update user role
router.put('/users/:id/role', authenticateAdmin, [
  body('role').isIn(['user', 'admin']).withMessage('Valid role is required')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { role } = req.body;
    const user = await User.findByIdAndUpdate(
      req.params.id,
      { role },
      { new: true }
    ).select('-password');

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    res.json({
      message: 'User role updated successfully',
      user
    });

  } catch (error) {
    console.error('Update user role error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Get all donations
router.get('/donations', authenticateAdmin, async (req, res) => {
  try {
    const { page = 1, limit = 10, status = '', bloodGroup = '', location = '' } = req.query;
    
    let query = {};
    
    if (status) {
      query.status = status;
    }
    
    if (bloodGroup) {
      query.bloodGroup = bloodGroup;
    }
    
    if (location) {
      query.location = { $regex: location, $options: 'i' };
    }

    const donations = await Donation.find(query)
      .populate('donor', 'fullName email bloodGroup city')
      .sort({ donationDate: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit);

    const total = await Donation.countDocuments(query);

    res.json({
      donations,
      totalPages: Math.ceil(total / limit),
      currentPage: page,
      total
    });

  } catch (error) {
    console.error('Get donations error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Update donation status
router.put('/donations/:id/status', authenticateAdmin, [
  body('status').isIn(['pending', 'approved', 'completed', 'rejected']).withMessage('Valid status is required'),
  body('notes').optional().trim()
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { status, notes } = req.body;
    const updateData = { status };
    
    if (notes) {
      updateData.notes = notes;
    }

    const donation = await Donation.findByIdAndUpdate(
      req.params.id,
      updateData,
      { new: true }
    ).populate('donor', 'fullName email bloodGroup');

    if (!donation) {
      return res.status(404).json({ message: 'Donation not found' });
    }

    // If donation is completed, update user's last donation date
    if (status === 'completed') {
      await User.findByIdAndUpdate(donation.donor._id, {
        lastDonationDate: donation.donationDate
      });
    }

    res.json({
      message: 'Donation status updated successfully',
      donation
    });

  } catch (error) {
    console.error('Update donation status error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Get all blood requests
router.get('/requests', authenticateAdmin, async (req, res) => {
  try {
    const { page = 1, limit = 10, status = '', urgency = '', bloodGroup = '' } = req.query;
    
    let query = {};
    
    if (status) {
      query.status = status;
    }
    
    if (urgency) {
      query.urgency = urgency;
    }
    
    if (bloodGroup) {
      query.bloodGroup = bloodGroup;
    }

    const requests = await BloodRequest.find(query)
      .populate('requester', 'fullName email bloodGroup city')
      .sort({ createdAt: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit);

    const total = await BloodRequest.countDocuments(query);

    res.json({
      requests,
      totalPages: Math.ceil(total / limit),
      currentPage: page,
      total
    });

  } catch (error) {
    console.error('Get requests error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Update blood request status
router.put('/requests/:id/status', authenticateAdmin, [
  body('status').isIn(['pending', 'approved', 'fulfilled', 'rejected', 'cancelled']).withMessage('Valid status is required'),
  body('notes').optional().trim()
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { status, notes } = req.body;
    const updateData = { status };
    
    if (notes) {
      updateData.notes = notes;
    }

    const request = await BloodRequest.findByIdAndUpdate(
      req.params.id,
      updateData,
      { new: true }
    ).populate('requester', 'fullName email bloodGroup');

    if (!request) {
      return res.status(404).json({ message: 'Blood request not found' });
    }

    res.json({
      message: 'Blood request status updated successfully',
      request
    });

  } catch (error) {
    console.error('Update request status error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Get dashboard statistics
router.get('/dashboard', authenticateAdmin, async (req, res) => {
  try {
    const totalUsers = await User.countDocuments();
    const totalDonations = await Donation.countDocuments();
    const totalRequests = await BloodRequest.countDocuments();
    
    const pendingDonations = await Donation.countDocuments({ status: 'pending' });
    const pendingRequests = await BloodRequest.countDocuments({ status: 'pending' });
    
    const bloodStock = await Donation.aggregate([
      {
        $match: {
          status: 'completed',
          expiryDate: { $gt: new Date() }
        }
      },
      {
        $group: {
          _id: '$bloodGroup',
          totalUnits: { $sum: '$quantity' }
        }
      },
      {
        $sort: { _id: 1 }
      }
    ]);

    const recentDonations = await Donation.find()
      .populate('donor', 'fullName bloodGroup')
      .sort({ donationDate: -1 })
      .limit(5);

    const recentRequests = await BloodRequest.find()
      .populate('requester', 'fullName bloodGroup')
      .sort({ createdAt: -1 })
      .limit(5);

    res.json({
      totalUsers,
      totalDonations,
      totalRequests,
      pendingDonations,
      pendingRequests,
      bloodStock,
      recentDonations,
      recentRequests
    });

  } catch (error) {
    console.error('Get dashboard error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Delete user (admin only)
router.delete('/users/:id', authenticateAdmin, async (req, res) => {
  try {
    const user = await User.findById(req.params.id);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Check if user has any donations or requests
    const hasDonations = await Donation.exists({ donor: req.params.id });
    const hasRequests = await BloodRequest.exists({ requester: req.params.id });

    if (hasDonations || hasRequests) {
      return res.status(400).json({ 
        message: 'Cannot delete user with existing donations or requests' 
      });
    }

    await User.findByIdAndDelete(req.params.id);

    res.json({ message: 'User deleted successfully' });

  } catch (error) {
    console.error('Delete user error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;
