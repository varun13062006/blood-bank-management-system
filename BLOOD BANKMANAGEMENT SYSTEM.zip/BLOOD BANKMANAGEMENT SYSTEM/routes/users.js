const express = require('express');
const { body, validationResult } = require('express-validator');
const User = require('../models/User');
const Donation = require('../models/Donation');
const BloodRequest = require('../models/BloodRequest');
const router = express.Router();

// Middleware to verify JWT token
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ message: 'Access token required' });
  }

  const jwt = require('jsonwebtoken');
  const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key';
  
  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({ message: 'Invalid or expired token' });
    }
    req.user = user;
    next();
  });
};

// Get user profile
router.get('/profile', authenticateToken, async (req, res) => {
  try {
    const user = await User.findById(req.user.userId).select('-password');
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    res.json(user);
  } catch (error) {
    console.error('Get profile error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Update user profile
router.put('/profile', authenticateToken, [
  body('fullName').optional().trim().isLength({ min: 2 }).withMessage('Full name must be at least 2 characters'),
  body('city').optional().trim().isLength({ min: 2 }).withMessage('City must be at least 2 characters'),
  body('phone').optional().trim(),
  body('address').optional().trim(),
  body('age').optional().isInt({ min: 18, max: 65 }).withMessage('Age must be between 18 and 65'),
  body('gender').optional().isIn(['Male', 'Female', 'Other']).withMessage('Valid gender is required')
], async (req, res) => {
  try {
    // Check validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const updates = req.body;
    delete updates.password; // Prevent password update through this route
    delete updates.email; // Prevent email update through this route
    delete updates.bloodGroup; // Prevent blood group update through this route
    delete updates.role; // Prevent role update through this route

    const user = await User.findByIdAndUpdate(
      req.user.userId,
      { $set: updates },
      { new: true, runValidators: true }
    ).select('-password');

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    res.json({
      message: 'Profile updated successfully',
      user
    });

  } catch (error) {
    console.error('Update profile error:', error);
    res.status(500).json({ message: 'Server error during profile update' });
  }
});

// Get user's donation history
router.get('/donations', authenticateToken, async (req, res) => {
  try {
    const donations = await Donation.find({ donor: req.user.userId })
      .sort({ donationDate: -1 })
      .populate('donor', 'fullName email bloodGroup');

    res.json(donations);
  } catch (error) {
    console.error('Get donations error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Get user's blood requests
router.get('/requests', authenticateToken, async (req, res) => {
  try {
    const requests = await BloodRequest.find({ requester: req.user.userId })
      .sort({ createdAt: -1 });

    res.json(requests);
  } catch (error) {
    console.error('Get requests error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Check donation eligibility
router.get('/eligibility', authenticateToken, async (req, res) => {
  try {
    const user = await User.findById(req.user.userId);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    const isEligible = user.checkEligibility();
    const lastDonation = user.lastDonationDate;
    
    let daysUntilEligible = 0;
    if (lastDonation && !isEligible) {
      const daysSinceLastDonation = Math.floor(
        (Date.now() - lastDonation.getTime()) / (1000 * 60 * 60 * 24)
      );
      daysUntilEligible = 56 - daysSinceLastDonation;
    }

    res.json({
      isEligible,
      lastDonationDate: lastDonation,
      daysUntilEligible,
      bloodGroup: user.bloodGroup,
      age: user.age,
      healthStatus: user.isEligible
    });

  } catch (error) {
    console.error('Check eligibility error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Get available blood stock for user's location
router.get('/blood-stock', authenticateToken, async (req, res) => {
  try {
    const user = await User.findById(req.user.userId);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    const stock = await Donation.aggregate([
      {
        $match: {
          status: 'completed',
          expiryDate: { $gt: new Date() }
        }
      },
      {
        $group: {
          _id: '$bloodGroup',
          totalUnits: { $sum: '$quantity' },
          availableUnits: {
            $sum: {
              $cond: [
                { $gt: ['$expiryDate', new Date()] },
                '$quantity',
                0
              ]
            }
          }
        }
      },
      {
        $sort: { _id: 1 }
      }
    ]);

    res.json({
      location: user.city,
      stock,
      lastUpdated: new Date()
    });

  } catch (error) {
    console.error('Get blood stock error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Change password
router.put('/change-password', authenticateToken, [
  body('currentPassword').notEmpty().withMessage('Current password is required'),
  body('newPassword').isLength({ min: 6 }).withMessage('New password must be at least 6 characters')
], async (req, res) => {
  try {
    // Check validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { currentPassword, newPassword } = req.body;

    const user = await User.findById(req.user.userId);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Verify current password
    const isCurrentPasswordValid = await user.comparePassword(currentPassword);
    if (!isCurrentPasswordValid) {
      return res.status(400).json({ message: 'Current password is incorrect' });
    }

    // Update password
    user.password = newPassword;
    await user.save();

    res.json({ message: 'Password changed successfully' });

  } catch (error) {
    console.error('Change password error:', error);
    res.status(500).json({ message: 'Server error during password change' });
  }
});

module.exports = router;
