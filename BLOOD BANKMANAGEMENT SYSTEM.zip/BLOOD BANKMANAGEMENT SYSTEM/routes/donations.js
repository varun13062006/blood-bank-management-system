const express = require('express');
const { body, validationResult } = require('express-validator');
const Donation = require('../models/Donation');
const User = require('../models/User');
const router = express.Router();

// Middleware to verify JWT token
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ message: 'Access token required' });
  }

  const jwt = require('jsonwebtoken');
  const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key';
  
  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({ message: 'Invalid or expired token' });
    }
    req.user = user;
    next();
  });
};

// Submit blood donation
router.post('/', authenticateToken, [
  body('bloodGroup').isIn(['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-']).withMessage('Valid blood group is required'),
  body('quantity').isInt({ min: 1, max: 2 }).withMessage('Quantity must be between 1 and 2 units'),
  body('location').trim().isLength({ min: 2 }).withMessage('Location is required'),
  body('healthCheck.hemoglobin').isFloat({ min: 12.5, max: 20 }).withMessage('Hemoglobin must be between 12.5 and 20'),
  body('healthCheck.bloodPressure.systolic').isInt({ min: 90, max: 180 }).withMessage('Systolic pressure must be between 90 and 180'),
  body('healthCheck.bloodPressure.diastolic').isInt({ min: 60, max: 110 }).withMessage('Diastolic pressure must be between 60 and 110'),
  body('healthCheck.pulse').isInt({ min: 50, max: 100 }).withMessage('Pulse must be between 50 and 100'),
  body('healthCheck.temperature').isFloat({ min: 36.1, max: 37.2 }).withMessage('Temperature must be between 36.1 and 37.2'),
  body('notes').optional().trim()
], async (req, res) => {
  try {
    // Check validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const user = await User.findById(req.user.userId);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Check if user is eligible for donation
    if (!user.checkEligibility()) {
      return res.status(400).json({ 
        message: 'You are not eligible for donation yet. Please wait 56 days from your last donation.' 
      });
    }

    // Check if user's age is within range
    if (user.age && (user.age < 18 || user.age > 65)) {
      return res.status(400).json({ 
        message: 'You must be between 18 and 65 years old to donate blood.' 
      });
    }

    const {
      bloodGroup,
      quantity,
      location,
      healthCheck,
      notes
    } = req.body;

    // Create new donation
    const donation = new Donation({
      donor: req.user.userId,
      bloodGroup,
      quantity,
      location,
      healthCheck,
      notes
    });

    await donation.save();

    res.status(201).json({
      message: 'Blood donation submitted successfully',
      donation: {
        id: donation._id,
        bloodGroup: donation.bloodGroup,
        quantity: donation.quantity,
        status: donation.status,
        donationDate: donation.donationDate,
        expiryDate: donation.expiryDate
      }
    });

  } catch (error) {
    console.error('Submit donation error:', error);
    res.status(500).json({ message: 'Server error during donation submission' });
  }
});

// Get donation by ID
router.get('/:id', authenticateToken, async (req, res) => {
  try {
    const donation = await Donation.findById(req.params.id)
      .populate('donor', 'fullName email bloodGroup city');

    if (!donation) {
      return res.status(404).json({ message: 'Donation not found' });
    }

    // Check if user is authorized to view this donation
    if (donation.donor._id.toString() !== req.user.userId && req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Access denied' });
    }

    res.json(donation);

  } catch (error) {
    console.error('Get donation error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Update donation (only by donor before approval)
router.put('/:id', authenticateToken, [
  body('location').optional().trim().isLength({ min: 2 }).withMessage('Location must be at least 2 characters'),
  body('notes').optional().trim()
], async (req, res) => {
  try {
    // Check validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const donation = await Donation.findById(req.params.id);
    if (!donation) {
      return res.status(404).json({ message: 'Donation not found' });
    }

    // Check if user is authorized to update this donation
    if (donation.donor.toString() !== req.user.userId) {
      return res.status(403).json({ message: 'Access denied' });
    }

    // Only allow updates if donation is still pending
    if (donation.status !== 'pending') {
      return res.status(400).json({ 
        message: 'Cannot update donation that has already been processed' 
      });
    }

    const updates = req.body;
    delete updates.bloodGroup; // Prevent blood group changes
    delete updates.quantity; // Prevent quantity changes
    delete updates.healthCheck; // Prevent health check changes
    delete updates.donor; // Prevent donor changes

    const updatedDonation = await Donation.findByIdAndUpdate(
      req.params.id,
      { $set: updates },
      { new: true, runValidators: true }
    ).populate('donor', 'fullName email bloodGroup');

    res.json({
      message: 'Donation updated successfully',
      donation: updatedDonation
    });

  } catch (error) {
    console.error('Update donation error:', error);
    res.status(500).json({ message: 'Server error during donation update' });
  }
});

// Cancel donation (only by donor if pending)
router.delete('/:id', authenticateToken, async (req, res) => {
  try {
    const donation = await Donation.findById(req.params.id);
    if (!donation) {
      return res.status(404).json({ message: 'Donation not found' });
    }

    // Check if user is authorized to cancel this donation
    if (donation.donor.toString() !== req.user.userId) {
      return res.status(403).json({ message: 'Access denied' });
    }

    // Only allow cancellation if donation is still pending
    if (donation.status !== 'pending') {
      return res.status(400).json({ 
        message: 'Cannot cancel donation that has already been processed' 
      });
    }

    await Donation.findByIdAndDelete(req.params.id);

    res.json({ message: 'Donation cancelled successfully' });

  } catch (error) {
    console.error('Cancel donation error:', error);
    res.status(500).json({ message: 'Server error during donation cancellation' });
  }
});

// Get available blood stock (public endpoint)
router.get('/stock/available', async (req, res) => {
  try {
    const { bloodGroup, location } = req.query;
    
    let query = {
      status: 'completed',
      expiryDate: { $gt: new Date() }
    };
    
    if (bloodGroup) {
      query.bloodGroup = bloodGroup;
    }
    
    if (location) {
      query.location = { $regex: location, $options: 'i' };
    }

    const stock = await Donation.aggregate([
      { $match: query },
      {
        $group: {
          _id: '$bloodGroup',
          totalUnits: { $sum: '$quantity' },
          locations: { $addToSet: '$location' }
        }
      },
      {
        $sort: { _id: 1 }
      }
    ]);

    res.json({
      stock,
      lastUpdated: new Date(),
      note: 'Stock levels are updated in real-time'
    });

  } catch (error) {
    console.error('Get stock error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Get donation statistics for a user
router.get('/stats/user', authenticateToken, async (req, res) => {
  try {
    const totalDonations = await Donation.countDocuments({ donor: req.user.userId });
    const completedDonations = await Donation.countDocuments({ 
      donor: req.user.userId, 
      status: 'completed' 
    });
    const pendingDonations = await Donation.countDocuments({ 
      donor: req.user.userId, 
      status: 'pending' 
    });

    const totalBloodDonated = await Donation.aggregate([
      { $match: { donor: req.user.userId, status: 'completed' } },
      { $group: { _id: null, total: { $sum: '$quantity' } } }
    ]);

    const bloodGroupStats = await Donation.aggregate([
      { $match: { donor: req.user.userId } },
      {
        $group: {
          _id: '$bloodGroup',
          count: { $sum: 1 },
          totalUnits: { $sum: '$quantity' }
        }
      },
      { $sort: { _id: 1 } }
    ]);

    res.json({
      totalDonations,
      completedDonations,
      pendingDonations,
      totalBloodDonated: totalBloodDonated[0]?.total || 0,
      bloodGroupStats,
      lastUpdated: new Date()
    });

  } catch (error) {
    console.error('Get donation stats error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;
